document.addEventListener("DOMContentLoaded", function () {
    console.log("Website Loaded Successfully");
});
